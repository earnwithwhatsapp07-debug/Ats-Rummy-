package com.atsrummy.demo;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout root;
    int score = 0;
    int[] cards = {3, 5, 4};

    int gold = Color.rgb(255, 210, 70);
    int dark = Color.rgb(0, 45, 41);
    int green = Color.rgb(0, 135, 91);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        home();
    }

    TextView label(String text, int size, int color) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER); t.setPadding(12, 12, 12, 12);
        return t;
    }

    Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(green));
        return b;
    }

    void base(String title) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(20, 28, 20, 20);
        root.setBackgroundColor(dark);
        setContentView(root);
        TextView heading = label(title, 30, gold);
        heading.setTypeface(null, Typeface.BOLD);
        root.addView(heading);
    }

    void home() {
        base("👑 ATS RUMMY");
        root.addView(label("Free practice card game", 18, Color.WHITE));
        root.addView(label("Practice points: " + score, 20, gold));
        Button play = button("PLAY RUMMY PRACTICE");
        root.addView(play);
        play.setOnClickListener(v -> game());
        Button rules = button("HOW TO PLAY");
        root.addView(rules);
        rules.setOnClickListener(v -> rules());
        root.addView(label("Demo only • No deposits • No withdrawals • No cash prizes", 14, Color.LTGRAY));
    }

    void game() {
        base("RUMMY PRACTICE");
        root.addView(label("Arrange the cards in ascending order", 18, Color.WHITE));
        TextView cardView = label(cards[0] + "     " + cards[1] + "     " + cards[2], 34, gold);
        root.addView(cardView);
        Button sort = button("CHECK SEQUENCE");
        root.addView(sort);
        TextView result = label("", 18, Color.WHITE);
        root.addView(result);
        sort.setOnClickListener(v -> {
            if (cards[0] < cards[1] && cards[1] < cards[2]) {
                score += 10;
                result.setText("Correct! +10 practice points");
                result.setTextColor(gold);
            } else {
                result.setText("Not in order yet. Try again!");
            }
            cardView.setText(cards[0] + "     " + cards[1] + "     " + cards[2]);
        });
        Button change = button("NEW PRACTICE HAND");
        root.addView(change);
        change.setOnClickListener(v -> {
            // A fixed, non-wagering practice sequence that changes each round.
            int a = (int)(System.currentTimeMillis() % 5) + 1;
            cards = new int[]{a + 2, a, a + 1};
            cardView.setText(cards[0] + "     " + cards[1] + "     " + cards[2]);
            result.setText("");
        });
        Button back = button("BACK TO HOME");
        root.addView(back);
        back.setOnClickListener(v -> home());
    }

    void rules() {
        base("HOW TO PLAY");
        root.addView(label("1. Practice arranging numbered cards.\\n\\n2. Put the numbers in ascending order.\\n\\n3. Correct sequences earn practice points only.\\n\\n4. Points have no cash value and cannot be bought, sold or withdrawn.", 18, Color.WHITE));
        Button back = button("BACK TO HOME");
        root.addView(back);
        back.setOnClickListener(v -> home());
    }
}
