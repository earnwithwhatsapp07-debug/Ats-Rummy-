ATS RUMMY - Android Studio starter project

This is a safe, offline practice-game demo. It does not include real-money play,
deposits, withdrawals, betting, cash prizes, referral commissions, or collection
of bank/UPI/OTP details.

How to build:
1. Install Android Studio on a computer.
2. Open this folder in Android Studio (Open project).
3. Allow Gradle sync and install the Android SDK if prompted.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the APK output location.

This starter project is not itself a compiled APK. The first build needs Android
Studio and the Android SDK.
